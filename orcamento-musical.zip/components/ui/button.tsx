// Placeholder para button.tsx
export const button = () => null;