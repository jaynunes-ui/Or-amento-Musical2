// Placeholder para label.tsx
export const label = () => null;