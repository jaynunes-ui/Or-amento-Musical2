// Placeholder para input.tsx
export const input = () => null;