// Placeholder para card.tsx
export const card = () => null;