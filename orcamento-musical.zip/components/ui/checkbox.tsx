// Placeholder para checkbox.tsx
export const checkbox = () => null;